from database import connect_db
from utils import hash_password, get_current_time, validate_input


def register():
    conn, cursor = connect_db()

    print("\n===== REGISTER USER =====")

    username = input("Enter Username: ")
    if not validate_input(username, "Username"):
        return

    email = input("Enter Email: ")
    if not validate_input(email, "Email"):
        return

    password = input("Enter Password: ")
    if not validate_input(password, "Password"):
        return

    hashed_password = hash_password(password)

    try:
        cursor.execute("""
        INSERT INTO users(username, email, password, created_at)
        VALUES (?, ?, ?, ?)
        """, (username, email, hashed_password, get_current_time()))

        conn.commit()
        print("User registered successfully.")

    except Exception as e:
        print("Error:", e)

    finally:
        conn.close()


def login():
    conn, cursor = connect_db()

    print("\n===== LOGIN =====")

    username = input("Enter Username: ")
    password = input("Enter Password: ")

    hashed_password = hash_password(password)

    cursor.execute("""
    SELECT * FROM users
    WHERE username=? AND password=?
    """, (username, hashed_password))

    user = cursor.fetchone()

    conn.close()

    if user:
        print(f"Welcome, {username}")
        return user
    else:
        print("Invalid username or password.")
        return None