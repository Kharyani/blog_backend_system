from database import connect_db
from utils import get_current_time, validate_input


def add_comment():
    conn, cursor = connect_db()

    print("\n===== ADD COMMENT =====")

    post_id = input("Enter Post ID: ")

    commenter = input("Enter Your Name: ")
    if not validate_input(commenter, "Name"):
        return

    message = input("Enter Comment: ")
    if not validate_input(message, "Comment"):
        return

    cursor.execute("""
    SELECT * FROM posts WHERE id=?
    """, (post_id,))

    post = cursor.fetchone()

    if not post:
        print("Invalid Post ID.")
        conn.close()
        return

    cursor.execute("""
    INSERT INTO comments(post_id, commenter, message, created_at)
    VALUES (?, ?, ?, ?)
    """, (post_id, commenter, message, get_current_time()))

    conn.commit()
    conn.close()

    print("Comment added successfully.")


def view_comments():
    conn, cursor = connect_db()

    post_id = input("Enter Post ID: ")

    cursor.execute("""
    SELECT commenter, message, created_at
    FROM comments
    WHERE post_id=?
    """, (post_id,))

    comments = cursor.fetchall()

    if not comments:
        print("No comments found.")
    else:
        print("\n===== COMMENTS =====")
        for comment in comments:
            print(f"""
Commenter: {comment[0]}
Message: {comment[1]}
Date: {comment[2]}
---------------------------
""")

    conn.close()