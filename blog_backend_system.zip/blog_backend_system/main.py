from database import create_tables
from auth import register, login
from posts import (
    create_post,
    view_posts,
    edit_post,
    delete_post,
    search_posts,
    filter_by_category,
    like_post,
    dislike_post
)
from comments import add_comment, view_comments
from users import view_profile


def main():

    create_tables()

    current_user = None

    while True:

        print("""
=====================================
 BLOG BACKEND DATA MANAGEMENT SYSTEM
=====================================

1. Register
2. Login
3. Create Post
4. View Posts
5. Edit Post
6. Delete Post
7. Add Comment
8. View Comments
9. Search Posts
10. Filter by Category
11. Like Post
12. Dislike Post
13. View Profile
14. Exit
""")

        choice = input("Enter Choice: ")

        if choice == "1":
            register()

        elif choice == "2":
            current_user = login()

        elif choice == "3":
            if current_user:
                create_post(current_user)
            else:
                print("Please login first.")

        elif choice == "4":
            view_posts()

        elif choice == "5":
            if current_user:
                edit_post(current_user)
            else:
                print("Please login first.")

        elif choice == "6":
            if current_user:
                delete_post(current_user)
            else:
                print("Please login first.")

        elif choice == "7":
            add_comment()

        elif choice == "8":
            view_comments()

        elif choice == "9":
            search_posts()

        elif choice == "10":
            filter_by_category()

        elif choice == "11":
            like_post()

        elif choice == "12":
            dislike_post()

        elif choice == "13":
            if current_user:
                view_profile(current_user)
            else:
                print("Please login first.")

        elif choice == "14":
            print("Exiting system...")
            break

        else:
            print("Invalid choice.")


if __name__ == "__main__":
    main()