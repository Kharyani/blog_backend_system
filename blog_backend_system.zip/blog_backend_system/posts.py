from database import connect_db
from utils import get_current_time, validate_input


def create_post(user):
    conn, cursor = connect_db()

    print("\n===== CREATE POST =====")

    title = input("Enter Title: ")
    if not validate_input(title, "Title"):
        return

    content = input("Enter Content: ")
    if not validate_input(content, "Content"):
        return

    category = input("Enter Category: ")
    if not validate_input(category, "Category"):
        return

    cursor.execute("""
    INSERT INTO posts(title, content, author_id, category, created_date)
    VALUES (?, ?, ?, ?, ?)
    """, (title, content, user[0], category, get_current_time()))

    conn.commit()
    conn.close()

    print("Post created successfully.")


def view_posts():
    conn, cursor = connect_db()

    cursor.execute("""
    SELECT posts.id, posts.title, posts.content,
           users.username, posts.category,
           posts.created_date, posts.likes, posts.dislikes
    FROM posts
    JOIN users ON posts.author_id = users.id
    """)

    posts = cursor.fetchall()

    if not posts:
        print("No posts available.")
    else:
        print("\n===== ALL POSTS =====")
        for post in posts:
            print(f"""
Post ID: {post[0]}
Title: {post[1]}
Content: {post[2]}
Author: {post[3]}
Category: {post[4]}
Date: {post[5]}
Likes: {post[6]}
Dislikes: {post[7]}
------------------------------------
""")

    conn.close()


def edit_post(user):
    conn, cursor = connect_db()

    post_id = input("Enter Post ID to edit: ")

    cursor.execute("""
    SELECT * FROM posts
    WHERE id=? AND author_id=?
    """, (post_id, user[0]))

    post = cursor.fetchone()

    if not post:
        print("Post not found or unauthorized.")
        conn.close()
        return

    new_title = input("Enter New Title: ")
    new_content = input("Enter New Content: ")

    cursor.execute("""
    UPDATE posts
    SET title=?, content=?
    WHERE id=?
    """, (new_title, new_content, post_id))

    conn.commit()
    conn.close()

    print("Post updated successfully.")


def delete_post(user):
    conn, cursor = connect_db()

    post_id = input("Enter Post ID to delete: ")

    cursor.execute("""
    SELECT * FROM posts
    WHERE id=? AND author_id=?
    """, (post_id, user[0]))

    post = cursor.fetchone()

    if not post:
        print("Post not found or unauthorized.")
        conn.close()
        return

    cursor.execute("DELETE FROM posts WHERE id=?", (post_id,))

    conn.commit()
    conn.close()

    print("Post deleted successfully.")


def search_posts():
    conn, cursor = connect_db()

    keyword = input("Enter keyword to search: ")

    cursor.execute("""
    SELECT id, title, category
    FROM posts
    WHERE title LIKE ?
    """, ('%' + keyword + '%',))

    results = cursor.fetchall()

    if not results:
        print("No matching posts found.")
    else:
        for post in results:
            print(f"ID: {post[0]} | Title: {post[1]} | Category: {post[2]}")

    conn.close()


def filter_by_category():
    conn, cursor = connect_db()

    category = input("Enter category: ")

    cursor.execute("""
    SELECT id, title
    FROM posts
    WHERE category=?
    """, (category,))

    results = cursor.fetchall()

    if not results:
        print("No posts found.")
    else:
        for post in results:
            print(f"ID: {post[0]} | Title: {post[1]}")

    conn.close()


def like_post():
    conn, cursor = connect_db()

    post_id = input("Enter Post ID to like: ")

    cursor.execute("""
    SELECT * FROM posts WHERE id=?
    """, (post_id,))

    post = cursor.fetchone()

    if not post:
        print("Post not found.")
        conn.close()
        return

    cursor.execute("""
    UPDATE posts
    SET likes = likes + 1
    WHERE id=?
    """, (post_id,))

    conn.commit()
    conn.close()

    print("Post liked successfully.")

def dislike_post():
    conn, cursor = connect_db()

    post_id = input("Enter Post ID to dislike: ")

    cursor.execute("""
    SELECT * FROM posts WHERE id=?
    """, (post_id,))

    post = cursor.fetchone()

    if not post:
        print("Post not found.")
        conn.close()
        return

    cursor.execute("""
    UPDATE posts
    SET dislikes = dislikes + 1
    WHERE id=?
    """, (post_id,))

    conn.commit()
    conn.close()

    print("Post disliked successfully.")