from database import connect_db
from utils import hash_password, get_current_time


def insert_sample_data():
    conn, cursor = connect_db()

    try:
        # Sample User
        cursor.execute("""
        INSERT INTO users(username, email, password, created_at)
        VALUES (?, ?, ?, ?)
        """, (
            "admin",
            "admin@gmail.com",
            hash_password("admin123"),
            get_current_time()
        ))

        user_id = cursor.lastrowid

        # Sample Posts
        posts = [
            ("Python Basics", "Python is easy to learn.", user_id, "Programming"),
            ("AI Future", "Artificial Intelligence is growing rapidly.", user_id, "Technology"),
            ("SQLite Guide", "SQLite is lightweight database.", user_id, "Database")
        ]

        for post in posts:
            cursor.execute("""
            INSERT INTO posts(title, content, author_id, category, created_date)
            VALUES (?, ?, ?, ?, ?)
            """, (
                post[0],
                post[1],
                post[2],
                post[3],
                get_current_time()
            ))

        conn.commit()

        print("Sample data inserted successfully.")

    except Exception as e:
        print("Error:", e)

    finally:
        conn.close()


if __name__ == "__main__":
    insert_sample_data()