from database import connect_db


def view_profile(user):
    conn, cursor = connect_db()

    print("\n===== USER PROFILE =====")

    print(f"User ID: {user[0]}")
    print(f"Username: {user[1]}")
    print(f"Email: {user[2]}")
    print(f"Created At: {user[4]}")

    cursor.execute("""
    SELECT COUNT(*)
    FROM posts
    WHERE author_id=?
    """, (user[0],))

    total_posts = cursor.fetchone()[0]

    print(f"Total Posts: {total_posts}")

    conn.close()