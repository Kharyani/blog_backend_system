import hashlib
from datetime import datetime


def hash_password(password):
    return hashlib.sha256(password.encode()).hexdigest()


def get_current_time():
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def validate_input(value, field_name):
    if not value.strip():
        print(f"{field_name} cannot be empty.")
        return False
    return True